make us   # Build the US version
make jp   # Build the Japanese version
make eu   # Build the EU version
